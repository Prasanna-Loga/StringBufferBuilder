package stringBufferDemo;
public class Demo1 {
	 
    public void StringBufferPerf()  {
 
        StringBuffer str = new StringBuffer("First");
        long startTime = System.currentTimeMillis();
        for (int i = 1; i <= 100000; i++) {
            str.append(i);
            str.append(i);
            str.append(i);
            str.append(i);
        }
        System.out.println("StringBuffer: " + (System.currentTimeMillis() - startTime) + " ms");
 
    }
 
    public void StringBuilderPerf() {
 
        StringBuilder str = new StringBuilder();
        long startTime = System.currentTimeMillis();
        for (int i = 1; i <= 100000; i++) {
            str.append(i);
            str.append(i);
            str.append(i);
            str.append(i);
        }
        System.out.println("StringBuilder: " + (System.currentTimeMillis() - startTime) + " ms");
 
    }
    public static void main(String[] args) {
 
        Demo1 Obj1 = new Demo1();
        Obj1.StringBufferPerf();
        Obj1.StringBuilderPerf();
    }
 
}
package stringBufferDemo;

class Stringchange {
	
	public String rest() {
		
		try {
			System.out.println("Starting...rest");
			Thread.sleep(10000);
			return "REST";
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public String rest1() {
		
		try {
			System.out.println("Starting...rest1");
			Thread.sleep(1000);
			return "REST";
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public void printBuffer(StringBuffer s) throws InterruptedException {
		int i = 1;
		System.out.println("Buffer : Original String: " + s);

		s.append(i + 2);
		System.out.println(s);
		s.append(i + 4);
		System.out.println(s);
		s.append(i + 6);
		System.out.println("Buffer : Final String: " + s);
	}
}

class threading extends Thread {
	Stringchange o = new Stringchange();
	StringBuffer s;

	threading(StringBuffer s, Object o) {
		this.s = s;
		this.o = (Stringchange) o;
	}

	@Override
	public void run() {

		try {
			System.out.println("Run mtd...");
			s.append(new Stringchange().rest()).append(new Stringchange1().rest1()).append(new StringBuilder("ZZZZ"));
			o.printBuffer(s);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}
}

public class Demo2 {
	public static void main(String[] args) throws InterruptedException {
		Stringchange s = new Stringchange();

		StringBuffer nstr = new StringBuffer("NEWSTRING");
		StringBuffer nstr1 = new StringBuffer("ANOTHERSTRING");

		threading second = new threading(nstr, s);
		threading third = new threading(nstr1, s);

		second.start();
		third.start();
	}
}

package stringBufferDemo;
class Stringchange1{
	public String rest(){
		try {
			System.out.println("Starting...rest");
			Thread.sleep(10000);
			return "REST";
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		return null;
	}
	
	public String rest1(){
		try {
			System.out.println("Starting...rest1");
			Thread.sleep(1000);
			return "Round";
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		return null;
	}
	public void printBuilder(StringBuilder s) throws InterruptedException{
		int i=1;
		System.out.println("Builder : Original String: "+s);
		
			s.append(i+2);
			System.out.println(s);
			s.append(i+4);
			System.out.println(s);
			s.append(i+6);
			
		System.out.println("Builder : Final String: "+s);
	}
}
class threading1 extends Thread{
	Stringchange1 o=new Stringchange1();
	StringBuilder s1;
	threading1(StringBuilder s1,Object o){
		this.s1=s1;
		this.o=(Stringchange1) o;
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			System.out.println("Run in builder...");
			s1.append(new Stringchange1().rest()).append(new Stringchange1().rest1()).append(new StringBuilder("ZZZZ"));
			o.printBuilder(s1);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
public class Demo3 {
	public static void main(String[] args) throws InterruptedException{
	Stringchange1 s=new Stringchange1();
	
	
	StringBuilder nstr1=new StringBuilder("NEWSTRING");
	StringBuilder nstr2=new StringBuilder("ANOTHERSTRING");
	
	threading1 second=new threading1(nstr1,s);
	threading1 third=new threading1(nstr2,s);
	
	second.start();
	third.start();
	}
}


